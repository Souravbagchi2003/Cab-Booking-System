let drive = 0
function runDriven() {
    setInterval(function () {
        if (drive <= 8800) {
            drive+= 47
            document.getElementById("driven").textContent = drive
        }
    },50)
}
runDriven()

let people1 = 0
function runPeople1() {
    setInterval(function () {
        if (people1 <= 478) {
            people1++
            document.getElementById("pdropped").textContent = people1
        }
    }, 25)
}
runPeople1()

let driver = 0
function runTaxi() {
    setInterval(function () {
        if (driver < 14) {
            driver++
            document.getElementById("taxidriver").textContent = driver
        }
    }, 100)
}
runTaxi()

let people2 = 0
function runPeople2() {
    setInterval(function () {
        if (people2 < 316) {
            people2++
            document.getElementById("phappy").textContent = people2
        }
    }, 25)
}
runPeople2()