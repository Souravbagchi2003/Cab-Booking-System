var cars = [
    {
        name: "Tata-Nexon", price: "49", model: "Smart(O) 1.2 Revotron",no:"WB-67-AD-1234", passenger: "2", luggage:"2", 
        driver: "ABC", data: "Regular",
        image: "https://www.carandbike.com/_next/image?url=https%3A%2F%2Fimages.carandbike.com%2Fcar-images%2Fcolors%2Ftata%2Fnexon%2Ftata-nexon-calgary-white.jpg%3Fv%3D1695383688&w=750&q=75",
        image1:"https://www.carlelo.com/source/IMG-20230213-WA0045.jpg",
        image2:"https://imgd-ct.aeplcdn.com/1056x660/n/cw/ec/157809/tata-nexon-dashboard10.jpeg?isig=0&wm=4&q=80",
    },
    {
        name: "Toyota", price: "89", model: "Urban Cruiser Taisor",no:"WB-67-QS-1235", passenger: "3", luggage:"2", 
        driver: "DEF", data: "Regular",
        image: "https://static3.toyotabharat.com/images/homepage/services/d27-whats-awesome-547x306.jpg",
        image1:"https://images-cdn.ubuy.co.in/63504b5992ce2f6d801226c2-custom-fit-car-seat-covers-for-toyota.jpg",
        image2:"https://static3.toyotabharat.com/images/showroom/innova-hycross/comfort-img04.webp",
    },
    {
        name: "Bolero", price: "99", model: "Bolero Neo Plus",no:"WB-67-AS-1236", passenger: "6", luggage:"5", 
        driver: "GHI", data: "Occasion",
        image: "https://imgd.aeplcdn.com/664x374/n/cw/ec/123643/bolero-neo-plus-exterior-right-front-three-quarter.png?isig=0&q=80",
        image1:"https://images.carandbike.com/car-images/gallery/mahindra/bolero/interior/mahindra-bolero-seating.jpg?v=2020-03-25",
        image2:"https://imgd.aeplcdn.com/1920x1080/n/cw/ec/131179/bolero-interior-steering-wheel.jpeg?isig=0&q=80&q=80",
    },
    {
        name: "BMW", price: "199", model: "BMW X3",no:"WB-67-DF-1237", passenger: "2", luggage:"1", 
        driver: "JKL", data: "Business",
        image: "https://d2m3nfprmhqjvd.cloudfront.net/blog/20230522183642/BMW-X3-1160x653.webp",
        image1:"https://cdn.bmwblog.com/wp-content/uploads/2016/07/Original-BMW-Accessories-9.jpg",
        image2:"https://www.bmw-m.com/content/dam/bmw/marketBMW_M/www_bmw-m_com/topics/magazine-article-pool/2022/bmw-xm-interieur/bmw-xm-innenraum-01-ai.jpg",
    },
    {
        name: "Audi", price: "189", model: "Audi A4",no:"WB-67-CV-1238", passenger: "1", luggage:"1", 
        driver: "MNO", data: "Business",
        // image: "https://imgd-ct.aeplcdn.com/1200x900/cw/ec/31252/Audi-A5-Right-Front-Three-Quarter-165509.jpg?wm=0&q=80",
        image: "https://imgd.aeplcdn.com/664x374/n/cw/ec/51909/a4-exterior-right-front-three-quarter-2.jpeg?q=80",
        image1:"https://m.media-amazon.com/images/I/51-pFwwuNgL._AC_UF1000,1000_QL80_.jpg",
        image2:"https://carsguide-res.cloudinary.com/image/upload/f_auto,fl_lossy,q_auto,t_cg__marking_background__sm_/v1/editorial/2018-Audi-A3-sportback-black-1200x800%20%2811%29.jpg",
    },
    {
        name: "Bolero", price: "109", model: "Bolero Neo",no:"WB-67-FG-1239", passenger: "5", luggage:"5", 
        driver: "PQR", data: "Family",
        image: "https://imgd-ct.aeplcdn.com/1200x900/n/cw/ec/131187/bolero-neo-right-front-three-quarter.jpeg?isig=0&q=80",
        image1:"https://images.carandbike.com/car-images/gallery/mahindra/bolero/interior/mahindra-bolero-seating.jpg?v=2020-03-25",
        image2:"https://imgd.aeplcdn.com/1920x1080/n/cw/ec/131179/bolero-interior-steering-wheel.jpeg?isig=0&q=80&q=80",
    },
    {
        name: "Scorpio", price: "119", model: "Scorpio S MT 7STR",no:"WB-67-ED-1240", passenger: "7", luggage:"7", 
        driver: "STU", data: "Family",
        image: "https://imgd.aeplcdn.com/664x374/n/cw/ec/128413/scorpio-exterior-right-front-three-quarter-47.jpeg?isig=0&q=80",
        image1:"https://cdni.autocarindia.com/ExtraImages/20220615072822_Scorpio.jpg",
        image2:"https://imgd-ct.aeplcdn.com/1056x660/n/cw/ec/31883/scorpio-interior-steering-wheel.jpeg?q=80",
    }
]



function addCars() {
    var clutter = ""
    cars.forEach(function (car, index) {
        clutter += `<div class="card" data-name=${car.data}>
        <img src="${car.image}" alt="car-pic" >
        <h3 class="text-3xl font-bold mt-5 mb-5">${car.name}</h3>
        <p class="text-lg"><b>Model:</b> <span class="right">${car.model}</span></p>
        <p class="text-lg"><b>Per Mile/KM:</b> <span class="right">$${car.price}</span></p>
        <p class="text-lg"><b>Passengers:</b> <span class="right">${car.passenger}</span></p><br>
        <a data-index="${index}" href="/cab" class="add px-10 py-5  text-center rounded-3xl text-xl font-semibold bg-amber-400 mt-4 mb-9">Book now</a>
        </div>`
        // <button data-index="${index}" class="add"><a data-index="${index}" href="taxi1.html" class="add">Book now</a></button>
    })
    document.querySelector("#filterable-cards").innerHTML = clutter;
}
addCars()

// Select relevant HTML elements
const filterButtons = document.querySelectorAll("#filter-buttons button");
const filterableCards = document.querySelectorAll("#filterable-cards .card");

// Function to filter cards based on filter buttons
const filterCards = (e) => {
    document.querySelector("#filter-buttons .active").classList.remove("active");
    e.target.classList.add("active");

    filterableCards.forEach(card => {
        // show the card if it matches the clicked filter or show all cards if "all" filter is clicked
        if (card.dataset.name === e.target.dataset.filter || e.target.dataset.filter === "all") {
            return card.classList.replace("hide", "show");
        }
        card.classList.add("hide");
    });
}

filterButtons.forEach(button => button.addEventListener("click", filterCards));



var cart = []

function addToCart() {
    document.querySelector("#filterable-cards").addEventListener("click", function (details) {
        if (details.target.classList.contains('add')) {
            // console.log("added complete")
            // console.log(details.target)
            // console.log(details.target.dataset.index)
            cart.push(cars[details.target.dataset.index])
            localStorage.setItem("carts", JSON.stringify(cart))
            console.log(cart)
        }
    })
}
addToCart()